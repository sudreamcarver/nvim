require("config.lazy")

-- lualine
-- --------------------------------------------------------------------------------------------------------
require('lualine').setup {
    options = {
        icons_enabled = true,
        theme = 'onelight',
        component_separators = { left = '', right = '' },
        section_separators = { left = '', right = '' },
        disabled_filetypes = {
            statusline = {},
            winbar = {},
        },
        ignore_focus = {},
        always_divide_middle = true,
        globalstatus = false,
        refresh = {
            statusline = 1000,
            tabline = 1000,
            winbar = 1000,
        }
    },
    sections = {
        lualine_a = { 'mode' },
        lualine_b = { 'branch', 'diff', 'diagnostics' },
        lualine_c = { 'filename' },
        lualine_x = { 'encoding', 'fileformat', 'filetype' },
        lualine_y = { 'progress' },
        lualine_z = { 'location' }
    },
    inactive_sections = {
        lualine_a = {},
        lualine_b = {},
        lualine_c = { 'filename' },
        lualine_x = { 'location' },
        lualine_y = {},
        lualine_z = {}
    },
    tabline = {},
    winbar = {},
    inactive_winbar = {},
    extensions = {}
}

require 'nvim-web-devicons'.setup {
    -- your personnal icons can go here (to override)
    -- you can specify color or cterm_color instead of specifying both of them
    -- DevIcon will be appended to `name`
    override = {
        zsh = {
            icon = "",
            color = "#428850",
            cterm_color = "65",
            name = "Zsh"
        }
    },
    -- globally enable different highlight colors per icon (default to true)
    -- if set to false all icons will have the default icon's color
    color_icons = true,
    -- globally enable default icons (default to false)
    -- will get overriden by `get_icons` option
    default = true,
    -- globally enable "strict" selection of icons - icon will be looked up in
    -- different tables, first by filename, and if not found by extension; this
    -- prevents cases when file doesn't have any extension but still gets some icon
    -- because its name happened to match some extension (default to false)
    strict = true,
    -- same as `override` but specifically for overrides by filename
    -- takes effect when `strict` is true
    override_by_filename = {
        [".gitignore"] = {
            icon = "",
            color = "#f1502f",
            name = "Gitignore"
        }
    },
    -- same as `override` but specifically for overrides by extension
    -- takes effect when `strict` is true
    override_by_extension = {
        ["log"] = {
            icon = "",
            color = "#81e043",
            name = "Log"
        }
    },
    -- same as `override` but specifically for operating system
    -- takes effect when `strict` is true
    override_by_operating_system = {
        ["apple"] = {
            icon = "",
            color = "#A2AAAD",
            cterm_color = "248",
            name = "Apple",
        },
    },
}

-- 自动在打开 .md 文件时加载 markdown.snippets，写入一次并返回
--vim.api.nvim_create_autocmd("BufReadPost", {
--pattern = "*.md",
--callback = function()
---- 获取当前缓冲区号和 snippets 文件路径
--local current_buf = vim.api.nvim_get_current_buf()
--local snippets_path = "~/.config/coc/ultisnips/markdown.snippets"
--
---- 打开 snippets 文件
--vim.cmd("edit " .. vim.fn.expand(snippets_path))
--
---- 写入一次并保存
--vim.cmd("write")
--
---- 切换回原始 .md 文件的缓冲区
--vim.api.nvim_set_current_buf(current_buf)
--end
--})


-- bufferline
----------------------------------------------------------------------------------------------
require("config.bufferline")

-- neo-tree
require("config.neo-tree")
require("config.autopair")
require("config.vimtable")
--
--
